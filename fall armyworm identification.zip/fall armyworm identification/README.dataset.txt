# Crop Pest Detection: Fall Armyworm > 2024-04-21 3:33pm
https://universe.roboflow.com/armandos-workspace-feyxi/crop-pest-detection-fall-armyworm

Provided by a Roboflow user
License: CC BY 4.0

